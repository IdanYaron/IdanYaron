
   
Hi there, I'm Barak 👋     | ⚡ Fun fact
:-------------------------:|:-------------------------:
[![Anurag's github stats](https://github-readme-stats.vercel.app/api?username=bsharabi&show_icons=true&layout=compact&line_height=28&card_width=30)](https://github.com/anuraghazra/convoychat) |  [![Top Langs](https://github-readme-stats.vercel.app/api/top-langs/?username=bsharabi&layout=compact&langs_count=30&exclude_repo=ML_learning&line_height=25)](https://github.com/anuraghazra/github-readme-stats)

<h3> 📫 Contact Me:</h3>

[![Linkedin Badge](https://img.shields.io/badge/-Linkedin-blue?style=flat-square&logo=Linkedin&logoColor=white&link=https://www.linkedin.com/in/bsharabi)](https://www.linkedin.com/in/bsharabi)


<!-- 
<div align="center">

<h3 align="left">Tools:</h3>
<p align="center">
<a href="https://www.java.com" target="Java"> <img src="https://github.com/tomchen/stack-icons/blob/master/logos/java.svg" alt="java" width="40" height="40"/>  </a>
<a href="https://www.python.org" target="Python"> <img src="https://github.com/tomchen/stack-icons/blob/master/logos/python.svg" alt="python" width="40" height="40"/>  </a>
<a href="https://en.wikipedia.org/wiki/C_(programming_language)" target="C"> <img src="https://upload.wikimedia.org/wikipedia/commons/thumb/1/18/C_Programming_Language.svg/1853px-C_Programming_Language.svg.png" alt="C" width="35" height="40"/>  </a>
<a href="https://en.wikipedia.org/wiki/HTML5" target="html"> <img src="https://github.com/get-icon/geticon/blob/master/icons/html-5.svg" alt="html" width="40" height="40"/>  </a>
<a href="https://www.jetbrains.com/idea/" title="Intellij IDEA"> <img src="https://github.com/tomchen/stack-icons/blob/master/logos/intellij-idea.svg" alt="Intellij IDEA" width="40" height="40"/></a>  
<a href="https://www.sqlite.org/index.html" target="SQLite-plain"> <img src="https://camo.githubusercontent.com/644b7c04356f7e17ee98274b9a7d59af01e06bc988e4c311c8259df425d13c18/68747470733a2f2f75706c6f61642e77696b696d656469612e6f72672f77696b6970656469612f636f6d6d6f6e732f392f39372f53716c6974652d7371756172652d69636f6e2e737667" alt="SQLite-plain" width="40" height="40"/></a>

<a href="https://www.adobe.com/products/photoshop" target="photoshop"> <img src="https://github.com/get-icon/geticon/blob/master/icons/adobe-photoshop.svg" alt="photoshop" width="40" height="40"/> 

<a href="https://ubuntu.com/" target="ubuntu"> <img src="https://user-images.githubusercontent.com/66886354/146211305-39e0ed43-b4d0-4155-b3fb-17eff634a6e8.png" alt="ubuntu" width="40" height="40"/> 
<a href="https://www.wireshark.org/" target="wireshark"> <img src="https://user-images.githubusercontent.com/66886354/147272381-c39e5aa2-3fd9-4a4d-ab9d-4c4c224b29ab.png" alt="wireshark" width="40" height="40"/> 
<a href="https://www.docker.com/" target="docker"> <img src="https://user-images.githubusercontent.com/66886354/147595427-103affab-641e-46ee-9986-ca534677e87d.png" alt="docker" width="40" height="40"/> 
</div>
 -->
